//Seleccionamos el contenedor principal
const container = document.querySelector(".container");

for (let index = 1; index <= 111; index++) {
    //Creamos un div
    const div = document.createElement("div");
    //Le añadimos la clase div-number
    div.className = "div-number";
    //Los colores elegidos son tonalidades mas suaves del morado, rojo y azul.
    if((index%3===0) && (index%5===0)){
        div.classList.toggle('purple');
    }
    else if(index%3===0){
        div.classList.toggle('red');
    }
    else if(index%5===0){
        div.classList.toggle('blue');
    }
    //  Añadimos los numeros al contenedor
    div.textContent = index;
    // Añadimos el div al contenedor principal
    container.insertAdjacentElement("beforeend", div);
}